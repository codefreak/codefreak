class Main {
  public static void main(String[] args) {
    System.out.printf("3 + 5 is %d", add(3, 5));
  }

  private static int add(int a, int b) {
    // Add the real implementation here
    return 0;
  }
}
