#include <stdio.h>

int add(int a, int b) {
    // Add the real implementation here
    return 0;
}

int main(int argc, char **argv) {
    printf("3 + 5 is %d", add(3, 5));
}
